int sensorPin = A0;

int greenLED = 2;
int yellowLED = 3;
int redLED = 4;

int buzzer = 5;

int relayPin = 6;   // Relay connected to pin 6

void setup() {

  pinMode(greenLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
  pinMode(redLED, OUTPUT);

  pinMode(buzzer, OUTPUT);

  pinMode(relayPin, OUTPUT);

  Serial.begin(9600);

  // Motor initially ON
  digitalWrite(relayPin, LOW);
}

void loop() {

  int waterLevel = analogRead(sensorPin);

  Serial.print("Water Level: ");
  Serial.println(waterLevel);

  // LOW LEVEL
  if (waterLevel < 300) {

    digitalWrite(greenLED, HIGH);
    digitalWrite(yellowLED, LOW);
    digitalWrite(redLED, LOW);

    noTone(buzzer);

    // Motor ON
    digitalWrite(relayPin, LOW);
  }

  // MEDIUM LEVEL
  else if (waterLevel >= 300 && waterLevel < 700) {

    digitalWrite(greenLED, LOW);
    digitalWrite(yellowLED, HIGH);
    digitalWrite(redLED, LOW);

    noTone(buzzer);

    // Motor ON
    digitalWrite(relayPin, LOW);
  }

  // HIGH LEVEL
  else {

    digitalWrite(greenLED, LOW);
    digitalWrite(yellowLED, LOW);
    digitalWrite(redLED, HIGH);

    tone(buzzer, 1000);

    // Motor OFF
    digitalWrite(relayPin, HIGH);
  }

  delay(500);
}